
var API = null;
function findAPI(win) {
  var findAttempts = 0;
  while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
    findAttempts++;
    if (findAttempts > 500) return null;
    win = win.parent;
  }
  return win.API;
}
function getAPI() {
  if (API == null) {
    API = findAPI(window);
    if ((API == null) && (window.opener != null)) {
      API = findAPI(window.opener);
    }
  }
  return API;
}
function LMSInitialize() {
  var api = getAPI();
  if (api) api.LMSInitialize("");
}
function LMSFinish() {
  var api = getAPI();
  if (api) {
    api.LMSSetValue("cmi.core.lesson_status", "completed");
    api.LMSSetValue("cmi.core.score.raw", "100");
    api.LMSCommit("");
    api.LMSFinish("");
  }
}
window.onload = function() { LMSInitialize(); };
window.onunload = function() { LMSFinish(); };
